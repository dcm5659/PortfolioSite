
$( document ).ready(function() {
 
});

$(window).resize(test);

	function test(){
		
    	var viewportWidth = $(window).width();
      console.log(viewportWidth);
    	if (viewportWidth < 600) {
            $("img").removeClass("rightCol").addClass("blueBG");
           
    	}
	}


// $(window).resize(function () {
// 	 alert("I am working");
//     var viewportWidth = $(window).width();
//     if (viewportWidth < 600) {
//             $("img").removeClass("rightCol").addClass("blueBG");
           
//     }
// });